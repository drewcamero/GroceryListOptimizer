import javax.swing.SwingUtilities;
//import com.sun.glass.ui.Timer;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton; 
import javax.swing.JProgressBar;
import javax.swing.JTextArea;

public class GroceryCover {
	
	final static int interval = 20;
	int counter;
	Timer time;
	JFrame cover = new JFrame();
	JButton start = new JButton("Start");
	JTextArea start1 = new JTextArea();
	JProgressBar loading = new JProgressBar();
	JLabel welcome1 = new JLabel("Grocery List Optimizer");
	JLabel welcome2 = new JLabel("Grocery List Optimizer");

	File uncheck = new File("Uncheck.txt");
	File temporary = new File("Tempo.txt");
	File sortedFile = new File("Sorted.txt");
	
	public GroceryCover(String[] args){
		
		start.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				
				counter = 0;
				time.start();
				start.setEnabled(false);
				cover.add(loading);
				
			}
		});//Start
		
		time = new Timer(interval, new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				

				sortedFile.delete();
				uncheck.delete();
				temporary.delete();
				
				if(counter==100){
					time.stop();
					GroceryMain.main(args);
					cover.dispose();
				}
				else{
					counter++;
					loading.setValue(counter);
				}
				
			}
		});
		
		loading = new JProgressBar(0,100);
		loading.setValue(0);
		loading.setStringPainted(true);
		
		//DEsigns
		cover.setLayout(null);
		cover.setBounds(450,100,450,450);
		cover.setVisible(true);
		cover.getContentPane().setBackground(Color.BLACK);
		cover.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cover.add(welcome1);
		welcome1.setBounds(24,30,400,45);
		welcome1.setForeground(Color.cyan);
		welcome1.setFont(new Font("Times New Roman", Font.BOLD, 38));
		cover.add(welcome2);
		welcome2.setBounds(28,34,400,45);
		welcome2.setForeground(Color.BLUE);
		welcome2.setFont(new Font("Times New Roman", Font.BOLD, 38));
		
		cover.add(start);
		start.setBounds(65,310,300,30);
		start.setForeground(Color.black);
		start.setBackground(Color.cyan);
		cover.add(start1);
		start1.setBounds(60,305,310,40);
		start1.setBackground(Color.blue);
		loading.setBounds(120,200,200,30);
		loading.setForeground(Color.blue);
		loading.setBackground(Color.black);
		
		
	}
	
	public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				new GroceryCover(args);
			}
		});
	}//public static void main
	
}//public class GroceryMain
