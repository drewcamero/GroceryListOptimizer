import javax.swing.SwingUtilities;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.DefaultListModel;
import javax.swing.JButton; 
import javax.swing.JList;

public class GrocerySubMenu {
	
	JFrame frmMenu = new JFrame("Summary");
	JLabel lblList = new JLabel("Summary of List:");
	JLabel lblChecked = new JLabel("Checked");
	@SuppressWarnings("rawtypes")
	JList listChecked = new JList();
	JLabel lblUncheck = new JLabel("Uncheck");
	@SuppressWarnings("rawtypes")
	JList listUncheck = new JList();
	JButton bttnBack = new JButton("Back");
	JButton bttnClose = new JButton("Close");

	@SuppressWarnings("rawtypes")
	DefaultListModel listModel4 = new DefaultListModel();
	@SuppressWarnings("rawtypes")
	DefaultListModel listModel5 = new DefaultListModel();
	
	String line1=null;
	String line2=null;
	File uncheck = new File("Uncheck.txt");
	File temporary = new File("Tempo.txt");
	File sortedFile = new File("Sorted.txt");
	
	@SuppressWarnings("unchecked")
	public GrocerySubMenu(String[] args){
		
		try{
			FileReader fr = new FileReader("Tempo.txt");
			BufferedReader br = new BufferedReader(fr);
				while((line1=br.readLine())!=null){
					listModel4.addElement(line1);
					listChecked.setModel(listModel4);
					}
				br.close();
				}
			catch (IOException objIOException) {
			}
		try{
			FileReader fr1 = new FileReader("Sorted.txt");
			BufferedReader br1 = new BufferedReader(fr1);
			FileReader fr2 = new FileReader("Tempo.txt");
			BufferedReader br2 = new BufferedReader(fr2);
			while((line2=br2.readLine())!=null){
				while((line1=br1.readLine())!=null){
					if(!line1.equals(line2)){
						PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Uncheck.txt"),true)));
						fw1.println(line1);
						fw1.close();
								}
							}br2.close();
							}br1.close();
							
							
						}
						catch (IOException objIOException) {
						}
		

		try{
			FileReader fr = new FileReader("Uncheck.txt");
			BufferedReader br = new BufferedReader(fr);
				while((line2=br.readLine())!=null){
					listModel5.addElement(line2);
					listUncheck.setModel(listModel5);
					}
				br.close();
				}
			catch (IOException objIOException) {
			}
		
		bttnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				uncheck.delete();
				temporary.delete();
				sortedFile.delete();
				GroceryMain.main(args);
				frmMenu.dispose();
			}
		});//bttnBack
		
		bttnClose.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				uncheck.delete();
				temporary.delete();
				sortedFile.delete();
				frmMenu.dispose();
			}
		});//bttnClose
		
	//Designs
		frmMenu.setVisible(true);
		frmMenu.setLayout(null);
		frmMenu.setBounds(450,100,450,450);
		frmMenu.getContentPane().setBackground(Color.BLACK);
		frmMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMenu.add(lblList);
		lblList.setBounds(10, 11, 104, 14);
		lblList.setForeground(Color.WHITE);
		frmMenu.add(lblChecked);
		lblChecked.setBounds(20, 31, 185, 20);
		lblChecked.setForeground(Color.WHITE);
		frmMenu.add(lblUncheck);
		lblUncheck.setBounds(229, 31, 185, 20);
		lblUncheck.setForeground(Color.WHITE);
		frmMenu.add(listChecked);
		listChecked.setBounds(20, 49, 185, 296);
		frmMenu.add(listUncheck);
		listUncheck.setBounds(229, 49, 185, 296);
		frmMenu.add(bttnBack);
		bttnBack.setBounds(260, 377, 65, 23);
		bttnBack.setBackground(Color.cyan);
		bttnBack.setForeground(Color.BLACK);
		frmMenu.add(bttnClose);
		bttnClose.setBounds(336, 377, 75, 23);
		bttnClose.setBackground(Color.cyan);
		bttnClose.setForeground(Color.BLACK);
		
		
	}//public GroceryMain(String[] args)
	
	public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				new GrocerySubMenu(args);
			}
		});
	}//public static void main
	
}//public class GroceryMain
