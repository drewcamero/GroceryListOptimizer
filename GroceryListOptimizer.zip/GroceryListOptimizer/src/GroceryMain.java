import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class GroceryMain {

	JFrame frmMain = new JFrame("Main Menu");
	JLabel lblList = new JLabel("List of Items:");
	@SuppressWarnings("rawtypes")
	JList listItems = new JList();
	JScrollPane scrollItems = new JScrollPane(listItems);
	@SuppressWarnings("rawtypes")
	JList listCheckItems = new JList();
	JScrollPane scrollCheckItems = new JScrollPane(listCheckItems);
	JButton bttnStart = new JButton("Start");
	JLabel lblCheck = new JLabel("Check List:");
	JButton bttnReset = new JButton("Reset");
	JButton bttnDone = new JButton("Done");
	JButton bttnClose = new JButton("Close");
	
	@SuppressWarnings("rawtypes")
	DefaultListModel listModel1 = new DefaultListModel();
	@SuppressWarnings("rawtypes")
	DefaultListModel listModel2 = new DefaultListModel();
	@SuppressWarnings("rawtypes")
	DefaultListModel listModel3 = new DefaultListModel();
	File uncheck = new File("Uncheck.txt");
	File temporary = new File("Tempo.txt");
	File sortedFile = new File("Sorted.txt");
	String toCheckItems = null;
	String line=null;
	int[] selectedItems;
	int[] selectedCheckItems;
	
	@SuppressWarnings("unchecked")
	public GroceryMain(String[] args){
		
		try{
		FileReader fr = new FileReader("Inventory.txt");
		BufferedReader br = new BufferedReader(fr);
			while((line=br.readLine())!=null){
				listModel1.addElement(line);
				listItems.setModel(listModel1);
				}
			br.close();
			}
		catch (IOException objIOException) {
		}
		
		listItems.addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent ibjLSE){
				listItems.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
				selectedItems = listItems.getSelectedIndices();
			}
		});//listITems.addlistselection
		
		listCheckItems.addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent ibjLSE){
				listCheckItems.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
				selectedCheckItems = listCheckItems.getSelectedIndices();
			}
		});//listCheckITems.addlistselection
		
		bttnClose.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				sortedFile.delete();
				uncheck.delete();
				temporary.delete();
				frmMain.dispose();
			}
		});//bttnClose
		
		bttnReset.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				sortedFile.delete();
				uncheck.delete();
				temporary.delete();
				listModel2.removeAllElements();
			}
		});
		
		bttnStart.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("biscuits.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("cannedgoods.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("drygoods.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("cleaners.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("hygiene.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("beverages.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("dairy.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("bread&pastry.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				for (int i = 0; i < selectedItems.length; i++) {
					toCheckItems =(String) listItems.getModel().getElementAt(selectedItems[i]);
					try{
						FileReader fr1 = new FileReader("meat.txt");
						BufferedReader br1 = new BufferedReader(fr1);
						while((line=br1.readLine())!=null){
							if(line.equals(toCheckItems)){
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Sorted.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
							}
						}
						br1.close();
					}
					catch (IOException objIOException) {
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				try{
					FileReader fr = new FileReader("Sorted.txt");
					BufferedReader br = new BufferedReader(fr);
						while((line=br.readLine())!=null){
							listModel2.addElement(line);
							listCheckItems.setModel(listModel2);
							}
						br.close();
						}
					catch (IOException objIOException) {
					}
				
				}//public void actionPerformed(ActionEvent onjAE){
			});//bttnStart
		
		bttnDone.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent onjAE){
				
				for (int i = 0; i < selectedCheckItems.length; i++) {
					toCheckItems =(String) listCheckItems.getModel().getElementAt(selectedCheckItems[i]);
					try{
							PrintWriter fw1 = new PrintWriter(new BufferedWriter(new FileWriter(("Tempo.txt"),true)));
							fw1.println(toCheckItems);
							fw1.close();
					}
					catch (IOException objIOException) {
						
					}
					}//for (int i = 0; i < selectedItems.length; i++) {
				
				GrocerySubMenu.main(args);
				frmMain.dispose();
			}
		});//bttnDone
		
	//Designs
		frmMain.setVisible(true);
		frmMain.setLayout(null);
		frmMain.setBounds(450,100,450,450);
		frmMain.getContentPane().setBackground(Color.BLACK);
		frmMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMain.add(lblList);
		lblList.setBounds(10, 11, 86, 14);
		lblList.setForeground(Color.WHITE);
		frmMain.add(bttnStart);
		bttnStart.setBounds(334, 26, 77, 100);
		bttnStart.setBackground(Color.cyan);
		bttnStart.setForeground(Color.BLACK);
		frmMain.add(lblCheck);
		lblCheck.setBounds(10, 140, 113, 14);
		lblCheck.setForeground(Color.WHITE);
		frmMain.add(scrollCheckItems);
		scrollCheckItems.setBounds(20, 160, 383, 200);
		frmMain.add(bttnReset);
		bttnReset.setBounds(20, 377, 70, 23);
		bttnReset.setBackground(Color.cyan);
		bttnReset.setForeground(Color.BLACK);
		frmMain.add(bttnDone);
		bttnDone.setBounds(260, 377, 65, 23);
		bttnDone.setBackground(Color.cyan);
		bttnDone.setForeground(Color.BLACK);
		frmMain.add(bttnClose);
		bttnClose.setBounds(336, 377, 75, 23);
		bttnClose.setBackground(Color.cyan);
		bttnClose.setForeground(Color.BLACK);
		frmMain.add(scrollItems);
		scrollItems.setBounds(20, 26, 290, 100);
		
	}//public GroceryMain(String[] args)
	
	public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
						new GroceryMain(args);
					
			}
		});
	}//public static void main
	
}//public class GroceryMain
